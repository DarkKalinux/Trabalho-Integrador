package com.example.chronosdiary;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateNoteActivity extends AppCompatActivity {

    // Declaração dos componentes da interface
    private EditText campoTitulo; 
    private EditText campoCategoria;
    private EditText campoConteudo;
    private Button botaoSalvar;

    // Instância do DatabaseHelper
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_note);

        // Inicializa os componentes da interface
        campoTitulo = findViewById(R.id.noteTitle);
        campoCategoria = findViewById(R.id.noteCategory);
        campoConteudo = findViewById(R.id.noteContent);
        botaoSalvar = findViewById(R.id.saveNoteButton);

        // Inicializa o DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Configura o listener do botão Salvar
        botaoSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Obtém o texto inserido pelo usuário
                String titulo = campoTitulo.getText().toString().trim();
                String categoria = campoCategoria.getText().toString().trim();
                String conteudo = campoConteudo.getText().toString().trim();

                // Verifica se todos os campos foram preenchidos
                if (titulo.isEmpty() || conteudo.isEmpty()) {
                    Toast.makeText(CreateNoteActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Salva a anotação no banco de dados
                boolean isSaved = salvarAnotacao(titulo, categoria, conteudo);

                if (isSaved) {
                    // Limpa os campos após salvar
                    campoTitulo.setText("");
                    campoCategoria.setText("");
                    campoConteudo.setText("");

                    Toast.makeText(CreateNoteActivity.this, "Anotação salva com sucesso!", Toast.LENGTH_SHORT).show();
                    finish(); // Finaliza a atividade após salvar
                } else {
                    Toast.makeText(CreateNoteActivity.this, "Erro ao salvar a anotação!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Método para salvar a anotação no banco de dados
    private boolean salvarAnotacao(String titulo, String categoria, String conteudo) {
        // Inserção no banco de dados usando DatabaseHelper
        return dbHelper.insertNote(titulo, categoria, conteudo);
    }
}