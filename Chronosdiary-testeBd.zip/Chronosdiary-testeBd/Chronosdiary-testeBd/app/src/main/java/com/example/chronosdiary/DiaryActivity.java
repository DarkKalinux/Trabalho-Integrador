package com.example.chronosdiary;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chronosdiary.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class DiarioActivity extends AppCompatActivity {

    private RecyclerView diarioRecyclerView;
    private DiarioAdapter diarioAdapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diario);

        diarioRecyclerView = findViewById(R.id.diaryRecyclerView);
        diarioRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DatabaseHelper(this);
        List<DiarioEntry> entradas = dbHelper.getAllNotes();

        diarioAdapter = new DiarioAdapter(entradas);
        diarioRecyclerView.setAdapter(diarioAdapter);
    }

}

