package com.example.chronosdiary;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    private ImageView logoImageMenu;
    private Button botaoCriarAnotacao, botaoDiario, botaoCategorias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Inicializando os componentes da tela
        logoImageMenu = findViewById(R.id.logoImageMenu);
        botaoCriarAnotacao = findViewById(R.id.createNoteButton);
        botaoDiario = findViewById(R.id.diaryButton);
        botaoCategorias = findViewById(R.id.categoriesButton);

        // Configurar o evento de clique para o botão "Criar Anotação"
        botaoCriarAnotacao.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, CriarAnotacaoActivity.class);
            startActivity(intent);
        });

        // Configurar o evento de clique para o botão "Diário"
        botaoDiario.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, com.example.chronosdiary.DiarioActivity.class);
            startActivity(intent);
        });

        // Configurar o evento de clique para o botão "Categoria"
        botaoCategorias.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, CategoriasActivity.class);
            startActivity(intent);
        });
    }
}
