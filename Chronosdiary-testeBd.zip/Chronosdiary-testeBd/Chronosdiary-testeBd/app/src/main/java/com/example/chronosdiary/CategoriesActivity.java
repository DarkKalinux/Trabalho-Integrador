package com.example.chronosdiary;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Arrays;
import java.util.List;

public class CategoriesActivity extends AppCompatActivity {

    private RecyclerView recyclerViewCategorias;
    private CategoryAdapter categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        // Inicializa o RecyclerView
        recyclerViewCategorias = findViewById(R.id.categoriesRecyclerView);
        recyclerViewCategorias.setLayoutManager(new LinearLayoutManager(this));

        // Lista de categorias (exemplo)
        List<String> categorias = Arrays.asList("Trabalho", "Estudo", "Pessoal", "Lazer");

        // Configura o adaptador
        categoryAdapter = new CategoryAdapter(categorias);
        recyclerViewCategorias.setAdapter(categoryAdapter);
    }
}

